package com.firstapplication.rokto.Email;

public class Util {
    // Add your own email and password over here.
    public  static  final String EMAIL = "aliftasbir@gmail.com";
    public static final String PASSWORD = "mamahoney";
}
